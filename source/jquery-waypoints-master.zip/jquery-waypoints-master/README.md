Waypoints isn't just for jQuery anymore!
=========================

With the release of Waypoints 3.0 the library no longer has a hard jQuery dependency, so the name has changed slightly. Please direct your attention to https://github.com/imakewebthings/waypoints
